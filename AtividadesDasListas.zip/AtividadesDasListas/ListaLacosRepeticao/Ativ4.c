#include <stdio.h>

int main(){
    int num = 0 , numeroMultiplo = 0;

    while( numeroMultiplo < 5){
        if(num % 3 == 0){
        if(numeroMultiplo == 4){
        printf("%d.", num);
   }else{
       printf("%d ,", num);
   }
    numeroMultiplo++;
    num++;
}
}
}

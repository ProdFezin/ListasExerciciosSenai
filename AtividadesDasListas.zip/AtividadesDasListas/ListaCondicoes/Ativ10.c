#include <stdio.h>

int main(){

   int num;

   printf("digite um numero");
   scanf("%d",&num);

       if (num%3==0 && num%5==0){
        printf("Divisivel\n");

       }else{
        printf("Indivisivel\n");
       }
   return 0;

}

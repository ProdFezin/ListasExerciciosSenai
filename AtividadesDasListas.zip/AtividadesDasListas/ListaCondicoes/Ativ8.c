#include <stdio.h>
#include <locale.h>

int man (){
    setlocale(LC_ALL, "");
 int semana;

        printf("digite um numero de 1 a 7 para mostrar o dia da semana correspondente.\n\n");
        printf("Digite o numero:");
        scanf("%d", &semana);

    switch(semana){
        case 1:
        printf ("domingo\n");
    break;
        case 2:
        printf ("segunda\n");
    break;
        case 3:
        printf ("ter�a\n");
    break;
        case 4:
        printf ("quarta\n");
    break;
        case 5:
        printf ("quinta\n");
    break;
        case 6:
        printf ("sexta\n");
    break;
        case 7:
        printf ("sabado\n");
    break;
    }
return 0
}

#include <stdlib.h>
#include <stdio.h>
#include <locale.h>

int main(){
    int vet[6];

    for(int i = 0; i < 6; i++){

        printf("Digite um numero: ");
        scanf("%d", &vet[i]);
    }
    for (int j = 6; j > 0; j--){

        if( j == 0+1){
            printf("%d. ", vet[j - 1]);

        } else {
            printf("%d, ", vet[j - 1]);
        }
    }
}

// Se funcionou � pq deu certo :p

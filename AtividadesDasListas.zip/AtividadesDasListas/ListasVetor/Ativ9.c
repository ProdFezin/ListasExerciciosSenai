#include <stdio.h>
#include <locale.h>
#include <stdlib.h>

int main(){
    int vetor[99], i, j = 0;

    for(i = 0; i < 99; i++){
        while(j % 7 == 0 || j % 10 == 7){
        j = j + 1;
        }
    vetor[i] = j;
    j = j + 1;
}
    printf(">> Vetor gerado aleatoriamente << \n\n");

    for(i = 0; i < 99; i++){
     printf("%d  ", vetor[i]);
}
}

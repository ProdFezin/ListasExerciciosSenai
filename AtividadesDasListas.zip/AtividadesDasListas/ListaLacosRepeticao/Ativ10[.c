#include <stdlib.h>
#include <locale.h>
#include <stdio.h>

int main(){
    int numero, soma = 0;
    float media = 0;

    for (int i =10; i > 0; i--){
        printf("Digite algum numero para fazer media:");
        scanf("%d", &numero);
        soma = soma + numero;
         if(numero < 0){

         }
    }
    media = soma / 10;
    printf ("A media final e: %.2f ", media);

}

#include <stdlib.h>
#include <locale.h>
#include <stdio.h>

int main(){
    int numero;

    printf("Digite um numeropositivo e realize a contagem:\n\n");
    scanf("%d", &numero);

    for(int i = 0; i <= numero; i++){
        if(i == numero){
            printf("%d. ", i);
        } else {
            printf("%d, ", i);
        }
    }

}

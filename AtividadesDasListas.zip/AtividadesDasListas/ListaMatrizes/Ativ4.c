#include <stdio.h>

int main(){

int matriz[4][4],l,c;

        for(l = 0; l < 4; l++){
            for(c = 0; c < 4; c++){
            printf("entre com o valor: \n");
            scanf("%d", &matriz[l][c]);
        }
    }
        for(l = 0; l < 4; l++){
            for(c = 0; c < 4; c++){
            if(matriz[l][c] > 10){
            printf("\nOs numeros maiores do que 10 sao = %d\n",matriz[l][c]);
            }
        }
    }
}


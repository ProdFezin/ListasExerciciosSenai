#include <stdio.h>
#include <locale.h>
int main(){
    setlocale(LC_ALL, "");
int num1, num2;

    printf("Digite dois numeros para mostrar o maoir.\n\n");
    printf("Digite o primeiro numero: ");
    scanf("%d", &num1);

    printf("Digite o segundo numero: ");
    scanf("%d", &num2);
    if(num1>num2){
        printf("%d", num1);
    }else{
        printf("%d", num2);
    }
    return 0;
}

#include <stdio.h>

int main(){

  int num = 10000;
  int linha = 0, coluna = 0;
  int matriz[4][4];

  for (int i = 0; i < 4; ++i) {
      for (int j = 0; j < 4; ++j) {
          scanf("%d", &matriz[i][j]);

          if (matriz[i][j] < num) {
              num = matriz[i][j];
              linha = i;
              coluna = j;
          }
      }
  }
  printf("%d %d", linha, coluna);
  return 0;
}



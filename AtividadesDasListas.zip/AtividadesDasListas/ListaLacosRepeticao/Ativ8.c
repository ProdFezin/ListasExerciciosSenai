#include <stdlib.h>
#include <locale.h>
#include <stdio.h>

int main(){
    setlocale(LC_ALL,"");
    int i, j, k = 0;
    float media;

    for(i = 0; i < 10; i ++){

    printf("Digite o %d� numero: ", i + 1);
    scanf("%d", &j);

    k = k + j;
}
    printf("Total: %d\j", k);
    media = k / 10;
    printf("M�dia: %.2f\j", media);

}

#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main(){
    int a[9],b[9],c[9];

    printf("Digite 10 numeros do seu vetor A:\n");
    system("cls");

    for(int i = 0; i < 9; i++){
        printf("[%i] =", i+1);
        scanf("%d", &a[i]);
}
    printf("\n");
    printf("Digite 10 numeros do seu vetor B:\n");
    system("cls");

    for(int i = 0; i < 9; i++){
        printf("[%i] =", i+1);
        scanf("%d", &b[i]);

}
    printf("\nC = A - B:\n");
        for(int i = 0; i < 9; i++){
        c[i]= a[i]-b[i];
        printf("[%i] = %d\n", i+1, c[i]);

}

}

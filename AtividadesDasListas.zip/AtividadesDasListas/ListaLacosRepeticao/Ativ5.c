#include <stdlib.h>
#include <locale.h>
#include <stdio.h>

int main(){
    int i = 1, numeroPar, soma;

    while(numeroPar < 50){
    if(i % 2 == 0){
        if(numeroPar == 49){
            printf("%d. ", i);
            } else {
                printf("%d, ", i);
            }
            soma = soma + i;
            numeroPar++;
            i++;
        } else {
        i++;
        }

    }
    printf("\nSoma final: %d. ", soma);
}

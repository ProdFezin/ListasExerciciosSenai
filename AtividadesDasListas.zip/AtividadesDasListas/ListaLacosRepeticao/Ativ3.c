#include <stdlib.h>
#include <stdio.h>

int main(){
int num ,i = 0,impar = 0;

printf("Digite um numero e veja quantos numeros da ordem s�o imapares.\n\n");
printf("Digite um numero inteiro: ");
scanf("%d", &num);
while( impar < num){
    if(i % 2 != 0){
        if (impar == num-1){
        printf("%d. ", i);
    } else {
        printf("%d, ", i);
    }
impar++;
i++;
} else {
i++;
    }
}
return 0;
}

#include <stdlib.h>
#include <locale.h>
#include <stdio.h>

int main(){

    int numeros, maior, menor;

    printf("Digite dez numeros inteiros: ");
    scanf("%d", &numeros);

    maior = numeros;
    menor = numeros;

    for(i = 1; i < 10; i++){
        printf("\nDigite o %d numero inteiro: ",i+1);
        scanf("%i", &numeros);

        if(numeros>maior){
            maior=numeros;
        }
        else if(numeros<menor){
            menor=numeros;
        }
}

    printf("\nO menor numero e: %d", menor);
    printf("\nO maior numero e: %d", maior);
}

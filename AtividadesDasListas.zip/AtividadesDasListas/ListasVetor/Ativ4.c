#include <stdio.h>
#include <locale.h>
#include <stdlib.h>
 int main(){
    int vet[8], a, b, c, soma;
    for(c=1;c<=8;c++)
    {
    printf("Digite os numeros do seu vetor:\n");
        scanf("%d", &vet[c]);
    }
    printf("Digite o valor do a: \n");
        scanf("%d", &a);

    printf("Digite o valor do b: \n");
        scanf("%d", &b);
    soma = vet[a] + vet[b];

    printf("\n A soma final e:%d",soma);
}



#include <stdio.h>
#include <locale.h>
#include <stdio.h>

 int main(){
    int vetor[10], mai = -5000, men = 5000;

    for(int i = 0; i < 10; i++){
        printf("Digite um valor: ");
        scanf("%d", &vetor[i]);
    }

    for(int i = 0; i < 10; i++){
        if(i == 10 - 1){
            printf("%d. ", vetor[i]);
        } else {
            printf("%d, ", vetor[i]);
        }
        if(vetor[i] < men){
            men = vetor[i];
        }
         if(vetor[i] > mai){
            mai = vetor[i];
        }
    }
    printf("\nMaior valor escrito: %d", mai);
    printf("\nMenor valor escrito: %d", men);
}

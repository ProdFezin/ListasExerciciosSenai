#include <stdlib.h>
#include <stdio.h>
#include <locale.h>

 int main(){
    float vetor[10], negativo, positivo;

    for(int i = 0; i < 10; i++){
        printf("Digite um numero: ");
        scanf("%f", &vetor[i]);
    }
    printf("Numeros digitados:\n");

    for(int i = 0; i < 10; i++){
        if(i == 10 - 1){
            printf("%.2f. ", vetor[i]);
        } else {
            printf("%.2f, ", vetor[i]);
        }
        if (vetor[i] < 0){
            negativo = negativo + vetor[i];
        } else {
            positivo = positivo + vetor[i];
        }
    }
    printf("\n\n\nA soma de totos os numeros *negativos* no vetor e: %.0f", negativo);
    printf("\n\nA soma de totos os numeros *positivos* no vetor e: %.0f", positivo);
    return 0;
}

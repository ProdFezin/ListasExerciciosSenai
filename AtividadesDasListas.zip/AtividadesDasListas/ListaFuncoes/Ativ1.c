#include <stdio.h>
#include <locale.h>

double maior(double a, double b){
    if(a > b){
        return(a);
    } else {
        return(b);
    }
}

int main() {
     setlocale(LC_ALL, "");

    double a, b;
    printf ("Digite a: ");
    scanf("%d", &a);
    printf ("Digite b: ");
    scanf("%d", &b);
    printf("O numero maior �: %d", maior(a, b));
}

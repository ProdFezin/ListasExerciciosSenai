#include <stdio.h >
#include <stdlib.h>
#define LEN 5


int main(){
    int A[LEN][LEN];
    int B[LEN][LEN];

    for(int i = 0; i < LEN; i++){
        for(int j = 0; j < LEN; j++){
            A[i][j] = rand() % 50;
            B[i][j] = A[i][j] * 2;
        }
    }

    printf("\nA:\n");

    for(int i = 0; i < LEN; i++){
        for(int j = 0; j < LEN; j++){
            printf("%d\t", A[i][j]);
        }
        printf("\n");
    }

    printf("\nB:\n");

    for(int i = 0; i < LEN; i++){
        for(int j = 0; j < LEN; j++){
            printf("%d\t", B[i][j]);
        }
        printf("\n");
    }

return 0;

}

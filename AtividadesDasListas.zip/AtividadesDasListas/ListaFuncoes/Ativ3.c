#include <stdio.h>
#include <locale.h>

int operacao(int *H, int *M, int *S){
    *M = *H * 60;
    *S = *M * 60;
}

int main() {
     setlocale(LC_ALL, "");

    int H, M, S;
    printf (">> Digite as horas <<\n\n>> ");
    scanf("%d", &H);
    system("cls");

    operacao(&H, &M, &S);
    printf(">> Resultado da Convers�o <<\n\n\nHoras >> %d\nMinutos >> %d\nSegundos >> %d\n\n", H, M, S);

}

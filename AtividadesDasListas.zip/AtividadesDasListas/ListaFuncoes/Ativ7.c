#include <stdlib.h>
#include <stdio.h>

float soma(float *num){
    *num = *num + 20;
    return *num;
}

int main() {

    float num;
    printf ("Digite um numero: ");
    scanf("%f", &num);
    soma(&num);
    printf("O numero somado a 20 e: %.0f \n\n", num);

}

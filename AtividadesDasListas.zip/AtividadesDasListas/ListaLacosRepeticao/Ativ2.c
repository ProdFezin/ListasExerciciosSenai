#include <stdlib.h>
#include <locale.h>
#include <stdio.h>

int main(){
    int numero;

    printf("Digite um numero e realize a contagem decrescente\n\n ");
    scanf("%d", &numero);

    for(int i = numero; i >= 0; i--){
        if(i == 0){
            printf("%d. ", i);
        } else {
            printf("%d, ", i);
        }
    }
}

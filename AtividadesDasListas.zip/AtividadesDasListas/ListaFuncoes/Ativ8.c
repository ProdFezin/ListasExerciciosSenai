#include <stdlib.h>
#include <stdio.h>

int main()
{
    int valor[5], i, soma=0;

    for(i=0; i<5; i++)
{
    printf("Qual o %d valor?\n ", i+1);
    scanf("%d", &valor[i]);
    soma= soma + valor[i];
}

    printf("A soma e: %d", soma);

    return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main(){

    setlocale(LC_ALL, "");
    float salario, prestacao;

        printf("Digite o salario: ");
        scanf("%f", &salario);

        printf("informe o valor da presta��o: ");
        scanf("%f", &prestacao);

            if(prestacao > salario * 0.2){
                printf("empr�stimo n�o concedido!");
            }else{
                printf("espr�stimo concedido!");
        }
    return 0;
}

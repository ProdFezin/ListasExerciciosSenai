#include <stdio.h>

void imprime(int rtd);

int main(){

imprime(5);
return 0;

}
void imprime (int rtd){
    for(int i = 0; i < qtd; i++){
        for(int j = 0; j <=i ;j++){
            printf("i");
        }
        printf("\n");
    }

}



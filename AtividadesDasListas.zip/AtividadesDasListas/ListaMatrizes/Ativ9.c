#include <stdio.h>

//testando atribui��o dentro dos ()
int main(int argc, const char * argv[]){

   int m[5][5], i, j, soma = 0;
    for(i = 0; i < 5; i++) {
       for(j = 0; j < 5; j++) {
           m[j][i] = i+j;
       }
   }
   for (i = 0; i < 5; i++) {
       for (j = 0; j < 5; j++) {
            if (j != i && 4 - i != j ){
               printf("%d ", m [i] [j]);
               soma += m [i] [j];
           }else{
               printf("0 ");
           }
       }
       printf("\n");
   }
   printf("a soma dos numeros e %d\n", soma);

   return 0;
}

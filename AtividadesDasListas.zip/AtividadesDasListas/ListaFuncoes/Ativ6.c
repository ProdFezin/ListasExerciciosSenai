#include <stdlib.h>
#include <stdio.h>

float soma(float *num){
    if( *num < 0){
        *num = 0;
    }else if(*num > 0){
        *num = *num * 5;
    }
    return *num;
}

int main() {

    float num;
    printf ("Digite um numero: ");
    scanf("%f", &num);
    soma(&num);
    printf("numero: %.0f \n\n", num);

}

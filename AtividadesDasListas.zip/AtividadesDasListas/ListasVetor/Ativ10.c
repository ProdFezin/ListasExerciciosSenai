#include <stdio.h>
#include <locale.h>
#include <stdlib.h>

int main(){

 int numero[9], i = 0, j = 0, extra;

    printf("Escreva 10 numeros:\n");

        for(i = 0; i < 9; i++){
            printf("[%i] =", i+1);
            scanf("%d", &numero[i]);
}

    printf("Numeros que se repetem:\n\n");
        for(i = 0; i < 9; i++){
        for(j = i+1; j < 9; j++){

     if(numero[j] == numero[i]){
        extra = numero[i];
        printf("%d\n", extra);

     }
   }
 }
return 0;
}

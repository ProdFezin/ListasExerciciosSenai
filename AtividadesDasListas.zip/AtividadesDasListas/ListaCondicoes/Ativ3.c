#include<stdio.h>

int main(){

   int num;

    printf("\n\nVeja se seu numero e impar ou par.\n\n")
    printf("Digite um numero: ");
    scanf("%d", &num);

   if(num % 2 == 0){
        printf("\nNumero Par\n\n");
   }
   else{
        printf("\nNumero Impar\n\n");
    }
 return 0;
}


#include <stdio.h>
#include <locale.h>

float conversao(float *C, float *F){
    *C = (*F-32) / 1.8;
    return *C;
}

int main() {
     setlocale(LC_ALL, "");

    float C, F;
    printf ("Digite temperatura em Fahrenheit: ");
    scanf("%f", &F);
    conversao(&C, &F);
    printf("A temperatura %.2f�F convertida em Celcius e de %.2f�C\n\n", F, C);

}

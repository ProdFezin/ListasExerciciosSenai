#include <stdio.h>
#include <math.h>
int main ( )
{
int num, quadrado, raiz;

       printf ("Digite um um numero:");
       scanf ("%d", &num);

       quadrado = pow (num, 2);
       printf ("Valor do numero ao quadrado %d\n", quadrado);

       raiz = sqrt (num);
       printf ("Valor da raiz quadrada %d", raiz);

  return 0;
}


#include <stdlib.h>
#include <stdio.h>
#include <locale.h>

int main(){
    int vet[6];

    for(int a = 0; a < 6; a++){
        printf("Digite um numero: ");
        scanf("%d", &vet[a]);
}
    for (int b = 6; b > 0; b--){
        if( b == 0+1){
            printf("%d. ", vet[b - 1]);

        }else{
            printf("%d, ", vet[b - 1]);
        }
    }
}
